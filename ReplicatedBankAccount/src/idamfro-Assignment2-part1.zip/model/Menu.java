package model;

public class Menu {
	
}
